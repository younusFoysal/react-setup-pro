import { Helmet } from 'react-helmet-async'


const Home = () => {
    return (
        <div>
            <Helmet>
                <title>HR Hub | Because People Matter</title>
            </Helmet>
           <h2>Home</h2>
        </div>
    )
}

export default Home
