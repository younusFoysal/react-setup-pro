# Server Template


## TODO:
1. Rename site name in package
2. Rename the mongodb name
3. Update EnvDot
